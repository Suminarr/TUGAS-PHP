<header role="banner">
    <div class="d-flex container" style="margin-left:100px; display:flex; gap:340px;">
    <h2>Student Activity Score - STTNF</h2>
    <div class="d-flex gap-3 mt-2">
    <a class="text-dark" href="#">Home</a> |
    <a class="text-dark" href="#">Activity</a> | 
    <a class="text-dark" href="#">My Score</a> |
    <a class="text-dark" href="#">Login</a>
    </div>
    </div>
</header>