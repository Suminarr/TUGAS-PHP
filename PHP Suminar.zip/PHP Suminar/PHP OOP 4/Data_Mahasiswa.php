<?php
    require_once 'Class_Mahasiswa.php';

    $mahasiswa =
?>