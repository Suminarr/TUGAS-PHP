<?php
class Lingkaran {
    private $jari;
    const PHI = 3.14;
    public function _construct($jari) {
        $this->jari = $jari;
    }
    public function luas() {
        return self::PHI * $this->jari * $this->jari;
    }
    public function keliling() {
        return 2 * self::PHI * $this->jari;
    }
}
?>