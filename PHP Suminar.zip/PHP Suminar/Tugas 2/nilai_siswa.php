<?php
$proses = $_POST['proses'];
$nama_siswa = $_POST['nama'];
$mata_kuliah = $_POST['matkul'];
$uts = $_POST['nilai_uts'];
$uas = $_POST['nilai_uas'];
$tugas = $_POST['nilai_tugas'];

echo "Nama : $nama_siswa";
echo "<br/>Mata Kuliah : $mata_kuliah";
echo "<br/>Nilai Uts: $uts";
echo "<br/>Nilai Uas : $uas";
echo "<br/>Nilai Tugas : $tugas";
echo "<br/> Data Telah di Proses";
?>
